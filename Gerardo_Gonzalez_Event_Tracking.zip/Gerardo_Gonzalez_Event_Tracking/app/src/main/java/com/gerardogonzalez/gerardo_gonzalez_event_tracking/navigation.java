package com.gerardogonzalez.gerardo_gonzalez_event_tracking;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class navigation extends RecyclerView.Adapter<navigation.ViewHolder> {

    private List<String> options;
    private OnItemClickListener listener;

    public navigation(List<String> options, OnItemClickListener listener) {
        this.options = options;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.activity_navigation, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        String option = options.get(position);
        holder.bind(option, listener);
    }

    @Override
    public int getItemCount() {
        return options.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {

        private TextView optionTextView;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            optionTextView = itemView.findViewById(R.id.textViewOption);
        }

        void bind(final String option, final OnItemClickListener listener) {
            optionTextView.setText(option);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onItemClick(option);
                }
            });
        }
    }

    public interface OnItemClickListener {
        void onItemClick(String option);
    }
}
