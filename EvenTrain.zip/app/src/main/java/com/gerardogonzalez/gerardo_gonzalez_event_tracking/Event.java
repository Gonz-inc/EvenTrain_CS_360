package com.gerardogonzalez.gerardo_gonzalez_event_tracking;

public class Event {


}
